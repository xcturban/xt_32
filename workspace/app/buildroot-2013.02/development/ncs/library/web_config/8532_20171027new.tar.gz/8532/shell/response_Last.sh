cp ../ini/sys_cfg_last.txt ../ini/sys_cfg.txt
web_tool 4

